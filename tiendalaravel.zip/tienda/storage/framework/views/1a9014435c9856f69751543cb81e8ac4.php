<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administración</title>
</head>
<body>
    
<h1>Administración</h1>

<h3>¿Que quieres administrar?</h3>

<button>Catálogo de productos</button>
<button>Categorías</button>
<button>Usuarios</button>


</body>
</html><?php /**PATH C:\Users\alumnat\Documents\GitHub\laraveltienda\tiendalaravel\tienda\resources\views/tiendavistas/administracion.blade.php ENDPATH**/ ?>