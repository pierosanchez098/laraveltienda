<?php

use App\Http\Controllers\AplicacionController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('tiendavistas.login');
});

Route::resource('tienda', AplicacionController::class);

Route::get('mostrarRegistro', [AplicacionController::class, 'mostrarRegistro'])->name('tienda.registro');
Route::get('mostrarLogin', [AplicacionController::class, 'mostrarLogin'])->name('tienda.login');
Route::get('registrar', [AplicacionController::class, 'registrar'])->name('tienda.registrar');
