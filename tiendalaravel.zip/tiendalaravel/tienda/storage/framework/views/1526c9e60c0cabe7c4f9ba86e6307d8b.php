<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administración</title>
</head>
<body>
    
<h1>Administración</h1>

<h3>¿Que quieres administrar?</h3>

<a href="<?php echo e(route('tienda.Mirarcrudcatalogo')); ?>">Catálogo de productos</a>
<a href="<?php echo e(route('tienda.Mirarcrudcategoria')); ?>">Categorías</a>
<a href="<?php echo e(route('tienda.Mirarcrudusuario')); ?>">Usuarios</a>


</body>
</html><?php /**PATH C:\Users\STEPHANO\Documents\GitHub\laraveltienda\tiendalaravel\tienda\resources\views/tiendavistas/administracion.blade.php ENDPATH**/ ?>