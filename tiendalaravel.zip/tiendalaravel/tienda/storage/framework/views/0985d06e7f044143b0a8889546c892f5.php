<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD usuarios</title>
</head>
<body>
    <h1>CRUD Usuario</h1>
    
    <h3>Crear usuario:</h3>

    <form action="<?php echo e(route('tienda.registrarporAdmin')); ?>" method="get" >

<label>Nick:</label>
<input type="text" name="nick">

<label>Email:</label>
<input type="text" name="email">

<label>Nombre:</label>
<input type="text" name="nombre">

<label>Apellidos:</label>
<input type="text" name="apellidos">

<label>DNI:</label>
<input type="text" name="dni">

<label>Fecha de nacimiento:</label>
<input type="date" name="fecha_nacimiento">

<label>Contraseña:</label>
<input type="text" name="contrasena">

<label>Rol:</label>
<input type="text" name="rol" placeholder="Usuario / Administrador">

<input type="submit" value="Crear usuario">

</form>

    <h3>Ver usuarios:</h3>

    <table>
        <thead>
            <tr>
                <th>Nick</th>
                <th>Email</th>
                <th>Nombre</th>
                <th>Apellidos</th>
                <th>DNI</th>
                <th>Fecha de Nacimiento</th>
                <th>Rol</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($usuario->nick); ?></td>
                <td><?php echo e($usuario->email); ?></td>
                <td><?php echo e($usuario->nombre); ?></td>
                <td><?php echo e($usuario->apellidos); ?></td>
                <td><?php echo e($usuario->dni); ?></td>
                <td><?php echo e($usuario->fecha_nacimiento); ?></td>
                <td><?php echo e($usuario->rol); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <h3>Actualizar usuario:</h3>
    <h3>Eliminar usuario:</h3>
</body>
</html><?php /**PATH C:\Users\STEPHANO\Documents\GitHub\laraveltienda\tiendalaravel\tienda\resources\views/tiendavistas/crudusuario.blade.php ENDPATH**/ ?>