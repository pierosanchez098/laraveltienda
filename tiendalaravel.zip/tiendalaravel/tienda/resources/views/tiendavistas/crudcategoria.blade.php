<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD Categoria</title>
</head>
<body>
    <h1>CRUD Categoria</h1>
    <h3>Crear categoria</h3>
    <h3>Ver categoria</h3>
    <h3>Actualizar categoria</h3>
    <h3>Eliminar categoria</h3>
</body>
</html>